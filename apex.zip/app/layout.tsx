import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { NextIntlClientProvider } from "next-intl";
import { getLocale } from "next-intl/server";
import "./globals.css";
import LoadingScreen from "@/components/LoadingScreen";
import MouseGlow from "@/components/MouseGlow";
import { SiteHeader, SiteChrome } from "@/components/SiteChrome";
import VisitTracker from "@/components/VisitTracker";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://apexflow.dev"),
  title: {
    default: "Apex Flow — Engineering Digital Momentum",
    template: "%s | Apex Flow",
  },
  description:
    "Full-stack, backend-focused development studio building production-ready SaaS, dashboards, and APIs.",
  keywords: [
    "NestJS developer",
    "Next.js developer",
    "full-stack developer",
    "SaaS development",
    "backend architecture",
  ],
  openGraph: {
    title: "Apex Flow — Engineering Digital Momentum",
    description:
      "Full-stack, backend-focused development studio building production-ready SaaS, dashboards, and APIs.",
    url: "https://apexflow.dev",
    siteName: "Apex Flow",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Apex Flow — Engineering Digital Momentum",
    description:
      "Full-stack, backend-focused development studio building production-ready SaaS, dashboards, and APIs.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: "#0a0e17",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const locale = await getLocale();
  const dir = locale === "ar" ? "rtl" : "ltr";

  return (
    <html
      lang={locale}
      dir={dir}
      className={`${geistSans.variable} ${geistMono.variable} h-full scroll-smooth antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <NextIntlClientProvider>
          <VisitTracker />
          <MouseGlow />
          <a href="#main" className="skip-link">
            Skip to content
          </a>

          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{
              __html: JSON.stringify({
                "@context": "https://schema.org",
                "@graph": [
                  {
                    "@type": "Organization",
                    "@id": "https://apexflow.dev/#organization",
                    name: "Apex Flow",
                    url: "https://apexflow.dev",
                    logo: "https://apexflow.dev/logo.png",
                  },
                  {
                    "@type": "Person",
                    "@id": "https://apexflow.dev/#person",
                    name: "Mohamed",
                    jobTitle: "Full-Stack Developer | Backend-Focused",
                    url: "https://apexflow.dev",
                    worksFor: { "@id": "https://apexflow.dev/#organization" },
                    knowsAbout: [
                      "NestJS",
                      "Node.js",
                      "TypeScript",
                      "PostgreSQL",
                      "Prisma",
                      "Next.js",
                      "React",
                    ],
                  },
                ],
              }),
            }}
          />

          <LoadingScreen />
          <SiteHeader />
          {children}
          <SiteChrome />
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
